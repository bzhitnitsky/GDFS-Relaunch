#!/bin/bash

sudo -u $USER /Applications/Fix\ Shared\ Drives.app/Contents/Resources/Shared_Fix_Dock.sh
